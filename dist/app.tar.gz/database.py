import sqlite3
import contextlib


class Database:
	def __init__(self):
		self.url = "database.db"


	def create_table(self):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute("""CREATE TABLE IF NOT EXISTS Tasks (
id INTEGER PRIMARY KEY,
time_stamp INTEGER NOT NULL,
indx INTEGER NOT NULL,
task TEXT NOT NULL,
completed BOOLEAN
)""")
			con.commit()
	
	def add_task(self, timestamp: int, index: int, task: str):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute('INSERT INTO Tasks (time_stamp, indx, task) VALUES (?, ?, ?)', (timestamp, index, task))
			con.commit()

	def update_task(self, timestamp: int, index: int, task: str):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			
			cursor.execute('UPDATE Tasks SET task = ? WHERE time_stamp = ? AND indx = ?', (task, timestamp, index))
			con.commit()

	def add_or_update_task(self, timestamp: int, index: int, task: str):
		_task = self.get_task(timestamp, index)

		if _task is None:
			self.add_task(timestamp, index, task)
		else:
			self.update_task(timestamp, index, task)
			


	def get_tasks(self, timestamp: int):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute('SELECT indx, task, completed FROM Tasks WHERE time_stamp = ?', (timestamp, ))
			return cursor.fetchall()

	def get_task(self, timestamp: int, index: int):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute('SELECT task FROM Tasks WHERE time_stamp = ? AND indx = ?', (timestamp, index))
			return cursor.fetchone()


	def get_last_index_task(self, timestamp: int):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute('SELECT MAX(indx) FROM Tasks WHERE time_stamp = ?', (timestamp, ))
			g = cursor.fetchone()[0]
			return -1 if g is None else g


	def toggle_task(self, timestamp: int, index: int, flag: bool):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute('UPDATE Tasks SET completed = ? WHERE time_stamp = ? AND indx = ?', (flag, timestamp, index))
			con.commit()

	def remove_task(self, timestamp: int, index: int):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute('DELETE FROM Tasks WHERE time_stamp = ? AND indx = ?', (timestamp, index))
			cursor.execute('UPDATE Tasks SET indx = indx-1 WHERE time_stamp = ? AND indx > ?', (timestamp, index))
			con.commit()

	def has_tasks(self, timestamp: int):
		with contextlib.closing(sqlite3.connect(self.url)) as con:
			cursor = con.cursor()
			cursor.execute('SELECT EXISTS (SELECT 1 FROM Tasks WHERE time_stamp = ?)', (timestamp, ))
			return cursor.fetchone()[0]