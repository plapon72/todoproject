import flet as ft
from datetime import datetime
import calendar
import copy
import sqlite3
from database import Database
from dataclasses import field, dataclass
from typing import Callable

database = Database()

@dataclass
class Task():
	page: ft.Page
	database: Database
	task_name: str = ""
	timestamp: int = 0
	index_in_list: int = 0
	is_completed: bool = False
	on_task_delete: Callable[["Task"], None] = field(default=lambda task: None)

	

	def build(self):
		text_field = ft.TextField(
					expand=True,
					label=f"Задача №{self.index_in_list+1}",
					label_style=ft.TextStyle(italic=self.is_completed, decoration=ft.TextDecoration.LINE_THROUGH if self.is_completed else ft.TextDecoration.NONE),
					text_style=ft.TextStyle(italic=self.is_completed, decoration=ft.TextDecoration.LINE_THROUGH if self.is_completed else ft.TextDecoration.NONE),
					value=self.task_name,
					on_submit=lambda e: database.add_or_update_task(self.timestamp, self.index_in_list, e.data),
					on_change=self.on_change,
					on_tap_outside=lambda _: database.add_or_update_task(self.timestamp, self.index_in_list, self.task_name),
					on_blur=lambda _: database.add_or_update_task(self.timestamp, self.index_in_list, self.task_name),
				)

		return ft.Container(content = ft.Row(width=1000, controls=[
			ft.Checkbox(value=self.is_completed, on_change=lambda e: self.toggle_task(e, text_field)),
			text_field,
			ft.IconButton(ft.Icons.DELETE, on_click=self.delete_clicked)
		], alignment=ft.alignment.center), 
		alignment=ft.alignment.center)


	def on_change(self, e):
		self.task_name = e.data

	def delete_clicked(self, e):
		tasks_list = e.control.parent.parent.parent
		task = e.control.parent.parent
		tasks_list.controls.remove(task)
		self.on_task_delete(self.timestamp, self.index_in_list)
		self.page.update()

	def toggle_task(self, e, textfield):
		self.is_completed = (e.data == "true")

		textfield.label_style=ft.TextStyle(italic=e.data, decoration=ft.TextDecoration.LINE_THROUGH if self.is_completed else ft.TextDecoration.NONE)
		textfield.text_style=ft.TextStyle(italic=e.data, decoration=ft.TextDecoration.LINE_THROUGH if self.is_completed else ft.TextDecoration.NONE)
		textfield.update()
		database.toggle_task(self.timestamp, self.index_in_list, self.is_completed)
		




def calendar_page(page: ft.Page):
	cells = ft.GridView(
		runs_count=7,
		semantic_child_count=5,
		horizontal=False,
		spacing=10,
		run_spacing=10,
		width=900,
		height=900
	)


	cells_container = ft.Container(content=cells, width=700, height=700, alignment=ft.alignment.center, margin=ft.margin.only(bottom=25))

	now = datetime.now()
	first_day = datetime(now.year, now.month, 1)
	day_number = first_day.weekday()
	timestamp = first_day.timestamp()
	current_timestamp = int(timestamp)
	t = 0
	controls = []

	is_started = False

	def get_color(timestamp):
		if datetime.fromtimestamp(timestamp).day < now.day:
			return ft.Colors.BLUE_GREY_500
		elif datetime.fromtimestamp(timestamp).day == now.day:
			return ft.Colors.GREEN
		elif database.has_tasks(timestamp):
			return ft.Colors.CYAN_200
		else:
			return ft.Colors.ON_SECONDARY_CONTAINER

	for y in range(len(calendar.monthcalendar(now.year, now.month))):
		for x in range(7):	
			if is_started is False and day_number == x and current_timestamp == timestamp:
				text = ft.Container(content = ft.Text(get_day_format(current_timestamp), size=24, weight=ft.FontWeight.W_600, color="black"), data=current_timestamp, width=200, height=200, alignment=ft.alignment.center)
				controls.append(ft.Container(content = text, width=200, height=200, bgcolor=get_color(current_timestamp), on_click = lambda e: go_to_day(page, e.control.content.data), border_radius=16))
				is_started = True

			elif is_started and first_day.month == datetime.fromtimestamp(current_timestamp).month:
				if current_timestamp != timestamp:
					text = ft.Container(content = ft.Text(get_day_format(current_timestamp), size=24, weight=ft.FontWeight.W_600, color="black"), data=current_timestamp, width=200, height=200, alignment=ft.alignment.center)
					controls.append(ft.Container(content = text, width=200, height=200, bgcolor=get_color(current_timestamp), on_click = lambda e: go_to_day(page, e.control.content.data),border_radius=16))


				current_timestamp += 24*60*60

			else:
				controls.append(ft.Container(width=200, height=200, bgcolor="#1e2129", border_radius=16))
				
	cells.controls = controls

	title_text = f'{["ЯНВАРЬ", "ФЕВРАЛЬ", "МАРТ", "АПРЕЛЬ", "МАЙ", "ИЮНЬ", "ИЮЛЬ", "АВГУСТ", "СЕНТЯБРЬ", "ОКТЯБРЬ", "НОЯБРЬ", "ДЕКАБРЬ"][now.month-1]} {now.year}'

	return create_view(
		page,
		"/",
		[
			ft.Column(controls=[
				ft.Container(content = ft.Text("КАЛЕНДАРЬ", size=50, weight=ft.FontWeight.W_600, color="white"), width=500, height=100, alignment=ft.alignment.center),
				ft.Container(content = ft.Text(title_text, size=32, weight=ft.FontWeight.W_600, color="white"), width=500, height=60, alignment=ft.alignment.center)
			], spacing=10),
			cells
		]
		
	)

def day_page(page: ft.Page, timestamp: int):

	tasks_none_text = ft.Container(content = ft.Text("Тут пока ничего нет...", size=27, weight=ft.FontWeight.W_600, italic=True, color=ft.Colors.BLUE_GREY_400), width=1000, height=100, alignment=ft.alignment.center)
	add_task_button = ft.Button(content=ft.Container(content=
		ft.Row(
			controls=[ft.Icon(ft.Icons.ADD, color=ft.Colors.PRIMARY, size=18), ft.Text(value="Добавить задачу", size=18)],
			alignment=ft.MainAxisAlignment.CENTER
		),
		width=200,
		height=50
	), on_click=lambda _: add_task())

	tasks = database.get_tasks(timestamp)
	tasks_list = ft.Column(width=1000, height=400, controls=[tasks_none_text], scroll=ft.ScrollMode.AUTO)

	def update_tasks_list(last_i=None):
		last_index = database.get_last_index_task(timestamp) if last_i is None else last_i
		tasks = database.get_tasks(timestamp)

		if last_index == -1:
			tasks_list.controls.clear()
			database.add_task(timestamp, last_index+1, "TODO")
			tasks_list.controls.append(Task(page=page, database=database, timestamp=timestamp, index_in_list=last_index+1, on_task_delete=delete_task).build())
		else:
			database.add_task(timestamp, last_index+1, "TODO")
			tasks_list.controls.append(Task(page=page, database=database, timestamp=timestamp, index_in_list=last_index+1, on_task_delete=delete_task).build())


		tasks_list.update()



	def load_tasks_list():
		tasks = database.get_tasks(timestamp)

		if len(tasks) > 0:
			tasks_list.controls.clear()
			[tasks_list.controls.append(Task(page=page, database=database, timestamp=timestamp, index_in_list=task[0], task_name=task[1] if task[1] != "TODO" else "", is_completed=task[2]==1, on_task_delete=delete_task).build()) for task in tasks]

	def add_task():
		update_tasks_list()
	
	def delete_task(timestamp, index):
		database.remove_task(timestamp, index)
		load_tasks_list()

	load_tasks_list()

	return create_view(
		page,
		"/day",
		[
			ft.Container(
				content=ft.Text(
					get_date_format(timestamp), 
					size=40, 
					weight=ft.FontWeight.W_600, 
					color="white"
				), 
				width=500, 
				height=80,
				alignment=ft.Alignment(0, 0.5),
				margin = ft.margin.only(top=20)
			),
			ft.Container(
				content=tasks_list,
				alignment=ft.Alignment(0,-0.5),
				expand=True
			),
			ft.Container(content=add_task_button, alignment = ft.Alignment(0.0, 1))
				
		
			

		]
	)

def go_to_day(page: ft.Page, i: int):
	page.go(f"/day/{i}")

def create_view(page: ft.Page, route: str = "", controls: list = []) -> ft.View:
	view = ft.View(route, controls)

	view.bottom_appbar = ft.BottomAppBar(content=ft.Row(
		controls=[
			ft.IconButton(icon=ft.Icons.CALENDAR_MONTH, icon_color=ft.Colors.WHITE, icon_size=40, on_click = lambda e: page.go("/")),
		], alignment=ft.MainAxisAlignment.CENTER, spacing=20
	))
	view.theme_mode = ft.ThemeMode.DARK
	view.vertical_alignment = ft.MainAxisAlignment.CENTER
	view.horizontal_alignment = ft.CrossAxisAlignment.CENTER
	view.spacing = 50
	view.expand = True

	return view

def get_page(page: ft.Page, route: str = "") -> ft.View:
	troute = ft.TemplateRoute(route)

	if troute.match("/"):
		return calendar_page(page)
	elif troute.match("/day/:day"):
		return day_page(page, int(troute.day))

def main(page: ft.Page):
	page.window.width = 360
	page.window.height = 802
	
	def view_pop(view):
		page.views.pop()
		top_view = page.views[-1]
		page.go(top_view.route)

	def route_change(route):
		page.views.clear()
		v = get_page(page, route.route)
		page.views.append(v)

		
		page.update()

	page.on_route_change = route_change
	page.on_view_pop = view_pop
	page.go(page.route)

def get_day_format(timestamp):
	date = datetime.fromtimestamp(timestamp)
	formatted_date = date.strftime('%d')
	return str(formatted_date)

def get_date_format(timestamp):
	date = datetime.fromtimestamp(timestamp)
	formatted_date = date.strftime('%d.%m.%Y')
	return str(formatted_date)
		

database.create_table()
ft.app(main)
